'use strict';
var timetable = timetable || {};
var list=[];

function find_date(day){
  if(day=="MO")
    return "monday";
  else if(day=="TU")
    return "tuesday";
  else if (day=="WE")
    return "wednesday";
  else if (day=="TH")
    return "thursday"
  else
    return "friday";
}
timetable.add_timetable = function(index,section){
  var name = data[index].code;
  var time = data[index].meeting_sections;
  for(var i=0; i<time.length;i++){

    if(time[i].section == section){
      var target = find_date(time[i].day);

      var ele = document.createElement("li");
      ele.setAttribute("class","single-event");
      ele.setAttribute("data-start",time[i].start);
      ele.setAttribute("data-end",time[i].end);
      ele.setAttribute("data-content","event-yoga-1");
      ele.setAttribute("data-event","event-3");

      var link =document.createElement("a");
      link.setAttribute("href","");

      var tag = document.createElement("em");
      tag.setAttribute("class","event-name");
      tag.innerHTML = data[index].code;
      link.appendChild(tag);
      ele.appendChild(link);
      document.getElementById(target).appendChild(ele);
    }

  }
}

//initialize the web page
timetable.init = function(){


  /*list = JSON.parse(window.localStorage.getItem("list"));
  for(var k=0;k<list.length;k++){
    this.add_timetable(list[k],'L0101');
  }*/
  this.add_timetable('0','L0101');
  //this.add_timetable('1','L0101');
}

//set up the page
timetable.init();
