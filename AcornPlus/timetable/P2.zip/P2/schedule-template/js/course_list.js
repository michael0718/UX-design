'use strict';
var Course = Course || {};



function ran_col() {
  var color = '#';
  var letters = ['f25945','6e4dbb','1d996d','fd8f26','24cccd','ffbfcd'];
  color += letters[Math.floor(Math.random() * letters.length)];
  document.getElementById('post').style.background = color;
  document.getElementById('blog').style.background = color;
}

//create the field for each course
Course.create_list = function(id,section,time){

  var field =document.createElement("div");
  field.setAttribute("class","course");

  var name = document.createElement("P");
  name.setAttribute("class","course_name");
  name.innerHTML=id;

  var sec = document.createElement("P");
  sec.setAttribute("class","course_section");
  sec.innerHTML=section;

  var ti = document.createElement("div");
  ti.setAttribute("class","course_time")

  for(var i=0; i<time.length;i++){

    if(time[i].section == section){
      var ele = document.createElement("P");
      ele.innerHTML=time[i].day +"  "+time[i].start + " - " +time[i].end + "       "+time[i].location;
      ti.appendChild(ele);
    }

  }
  field.appendChild(name);
  field.appendChild(sec);
  field.appendChild(ti);
  document.getElementById("course_list").appendChild(field);


}

//initialize the web page
Course.init = function(){

  //set the on click function for back button
  document.getElementById("back_button").onclick = function(){
    window.history.back();
  }
  this.create_list(data[0].code,"L0101",data[0].meeting_sections);

}

//set up the page
Course.init();
