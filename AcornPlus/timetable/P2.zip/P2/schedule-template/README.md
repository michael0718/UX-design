Schedule Template
=========

A simple template that let you display events on a timeline, as well as organize them in groups (week days, conference rooms etc…)

[Article on CodyHouse](https://codyhouse.co/gem/schedule-template/)

[Demo](https://codyhouse.co/demo/schedule-template/index.html)

[Terms](https://codyhouse.co/terms/)
