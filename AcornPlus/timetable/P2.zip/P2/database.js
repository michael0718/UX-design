var data=[
   {
      "link": "http://calendar.artsci.utoronto.ca/crs_csc.htm#CSC165H1",
      "code": "CSC165H1F",
      "meeting_sections": [
         {
            "start": "19:00",
            "end": "21:00",
            "section": "L0501",
            "location": "BR200",
            "day": "TH"
         },
         {
            "start": "18:00",
            "end": "21:00",
            "section": "L0501",
            "location": "BR200",
            "day": "TU"
         },
         {
            "start": "09:00",
            "end": "10:00",
            "section": "L0101",
            "location": "LM159",
            "day": "TU"
         },
         {
            "start": "11:00",
            "end": "12:00",
            "section": "L0101",
            "location": "LM159",
            "day": "FR"
         },
         {
            "start": "11:00",
            "end": "12:00",
            "section": "L0101",
            "location": "MS2158",
            "day": "WE"
         },
         {
            "start": "11:00",
            "end": "12:00",
            "section": "L0101",
            "location": "LM159",
            "day": "MO"
         }
      ]
   },
   {
      "link": "http://calendar.artsci.utoronto.ca/crs_csc.htm#CSC148H1",
      "code": "CSC148H1F",
      "meeting_sections": [
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "BA1160",
            "day": "MO"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "BA1160",
            "day": "WE"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "BA1160",
            "day": "FR"
         },
         {
            "start": "14:00",
            "end": "15:00",
            "section": "L0201",
            "location": "BA1160",
            "day": "MO"
         },
         {
            "start": "14:00",
            "end": "15:00",
            "section": "L0201",
            "location": "BA1160",
            "day": "WE"
         },
         {
            "start": "14:00",
            "end": "15:00",
            "section": "L0201",
            "location": "BA1160",
            "day": "FR"
         }
      ]
   },
   {
      "link": "http://calendar.artsci.utoronto.ca/crs_csc.htm#CSC108H1",
      "code": "CSC108H1F",
      "meeting_sections": [
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "WB116",
            "day": "MO"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "WB116",
            "day": "WE"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "WB116",
            "day": "FR"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0102",
            "location": "HS610",
            "day": "MO"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0102",
            "location": "AH100",
            "day": "WE"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0102",
            "location": "AH100",
            "day": "FR"
         },
         {
            "start": "13:00",
            "end": "14:00",
            "section": "L0201",
            "location": "MB128",
            "day": "MO"
         },
         {
            "start": "13:00",
            "end": "14:00",
            "section": "L0201",
            "location": "MB128",
            "day": "WE"
         },
         {
            "start": "13:00",
            "end": "14:00",
            "section": "L0201",
            "location": "MB128",
            "day": "FR"
         },
         {
            "start": "18:00",
            "end": "21:00",
            "section": "L0501",
            "location": "MS3154",
            "day": "WE"
         }
      ]
   },
   {
      "link": "http://calendar.artsci.utoronto.ca/crs_csc.htm#CSC207H1",
      "code": "CSC207H1F",
      "meeting_sections": [
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "BA1170",
            "day": "MO"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "BA1170",
            "day": "WE"
         },
         {
            "start": "10:00",
            "end": "11:00",
            "section": "L0101",
            "location": "BA1170",
            "day": "FR"
         },
         {
            "start": "14:00",
            "end": "15:00",
            "section": "L0201",
            "location": "RW117",
            "day": "MO"
         },
         {
            "start": "12:00",
            "end": "13:00",
            "section": "L0201",
            "location": "RW117",
            "day": "WE"
         },
         {
            "start": "12:00",
            "end": "13:00",
            "section": "L0201",
            "location": "RW117",
            "day": "FR"
         },
         {
            "start": "13:00",
            "end": "14:00",
            "section": "L0301",
            "location": "LM161",
            "day": "FR"
         },
         {
            "start": "14:00",
            "end": "16:00",
            "section": "L0301",
            "location": "LM161",
            "day": "FR"
         },
         {
            "start": "17:00",
            "end": "18:00",
            "section": "L5101",
            "location": "LM161",
            "day": "WE"
         },
         {
            "start": "18:00",
            "end": "20:00",
            "section": "L5101",
            "location": "LM161",
            "day": "WE"
         }
      ]
   },
   {
      "link": "http://calendar.artsci.utoronto.ca/crs_csc.htm#CSC236H1",
      "code": "CSC236H1F",
      "meeting_sections": [
         {
            "start": "11:00",
            "end": "12:00",
            "section": "L0101",
            "location": "RW110",
            "day": "MO"
         },
         {
            "start": "11:00",
            "end": "12:00",
            "section": "L0101",
            "location": "RW110",
            "day": "WE"
         },
         {
            "start": "11:00",
            "end": "12:00",
            "section": "L0101",
            "location": "RW110",
            "day": "FR"
         },
         {
            "start": "13:00",
            "end": "14:00",
            "section": "L0201",
            "location": "BA1170",
            "day": "MO"
         },
         {
            "start": "13:00",
            "end": "14:00",
            "section": "L0201",
            "location": "BA1170",
            "day": "WE"
         },
         {
            "start": "13:00",
            "end": "14:00",
            "section": "L0201",
            "location": "BA1170",
            "day": "FR"
         },
         {
            "start": "12:00",
            "end": "13:00",
            "section": "L0301",
            "location": "BA1170",
            "day": "MO"
         },
         {
            "start": "12:00",
            "end": "13:00",
            "section": "L0301",
            "location": "BA1170",
            "day": "WE"
         },
         {
            "start": "12:00",
            "end": "13:00",
            "section": "L0301",
            "location": "BA1170",
            "day": "FR"
         },
         {
            "start": "118:00",
            "end": "20:00",
            "section": "L5101",
            "location": "BA1180",
            "day": "WE"
         },
         {
            "start": "20:00",
            "end": "21:00",
            "section": "L5101",
            "location": "BA1180",
            "day": "WE"
         }
      ]
   }
]
