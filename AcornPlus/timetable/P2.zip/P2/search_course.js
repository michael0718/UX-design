'use strict';
var Home = Home || {};
var session;//global var for different session,0 for unselect,1 for fall, 2 for spring
var count;//total count for course
var list = [];//the list of courses add in the cart

//add onclick for generate button on home page
Home.generate_timetable =function(){
  document.getElementById("generate_but").addEventListener("click",function(){
    if(count == 0){
      alert("You don't have any courses");
    }
    else{
      window.localStorage.setItem("list", JSON.stringify(list));
      window.location.href = "course_list.html";
    }
  })
}

//add serached course in cart
Home.add_course = function(){
  document.getElementById("add").addEventListener("click",function(){

    var input = document.getElementById("input").value;
    var change = input.toUpperCase();
    //detect which session
    if(document.getElementById("fall").checked){
      session=1;
      change = change + "H1F";
    }
    if(document.getElementById("winter").checked){
      session=2;
      change = change + "H1S";
    }

    //session not been select
    if(session == 0){
      alert("You have not select session");
    }
    //reach maximum workload
    else if(count>4){
      alert("You have reached maximum courseload")
    }
    else{

      var found = -100;

      //find the course index in the database
      for(var i=0; i<data.length;i++){
        if(change == data[i].code)
        {
          found = i;
        }
      }
      var found_sw = 0;
      //check if the course is already add to list
      for(var j=0; j<list.length;j++){
        if(list[j]==found)
          found_sw=1;
      }

      if(found == -100){
        alert("Course name not found");
      }
      else if(found_sw == 1){
        alert("Course already added");
      }
      else{
        //add the course in the list
        list.push(found);

        //add sort buttons
        if(count == 0){
          var tar = document.getElementById("sort_menu");

          var sort_time = document.createElement("button");
          sort_time.setAttribute("id","s_t");
          sort_time.innerHTML="Sort by Time";

          var sort_loc = document.createElement("button");
          sort_loc.setAttribute("id","s_l");
          sort_loc.innerHTML="Sort by Location";

          var sort_prof = document.createElement("button");
          sort_prof.setAttribute("id","s_p");
          sort_prof.innerHTML="Sort by Professor";

          tar.appendChild(sort_time);
          tar.appendChild(sort_loc);
          tar.appendChild(sort_prof);
        }

        //create the field for course
        var ele = document.createElement("div");
        ele.setAttribute("class","course");
        ele.setAttribute("id",found);
        ele.setAttribute("style","background-color: grey; color: white; width: 30%; padding: 5px;border-radius: 10px");

        var name = document.createElement("P");
        name.setAttribute("class","course_name");
        name.innerHTML = data[found].code;

        var delete_but = document.createElement("button");
        delete_but.setAttribute("class","delet_button");
        var delete_img = document.createElement("img");
        delete_img.setAttribute("src","img/delete.png");
        delete_img.setAttribute("style","width:15px;height:15px");

        var course_link = document.createElement("a");
        course_link.setAttribute("href",data[found].link);
        course_link.setAttribute("target","_blank");
        course_link.innerHTML="Course Information";
        course_link.setAttribute("style","font-size: 50%");
        delete_but.appendChild(delete_img);

        delete_but.onclick = function(){
          var temp =[];
          //remove the item from array list
          for(var k=0; k<data.length;k++){
            if(list[k] != ele.id)
              temp.push(list[k]);
          }

          //remove the sort button
          if(count ==1){
            document.getElementById("s_t").remove();
            document.getElementById("s_l").remove();
            document.getElementById("s_p").remove();
          }
          list=temp;

          ele.remove();
          count--;
        }
        ele.appendChild(name);
        ele.appendChild(course_link);
        ele.appendChild(delete_but);
        document.getElementById("coursefeed").appendChild(ele);
        count++;
      }


    }
  })
}

//set up the page
Home.init = function(){
  session=0;
  count=0;
  this.add_course();
  this.generate_timetable();
}
//initializing home page
Home.init();
